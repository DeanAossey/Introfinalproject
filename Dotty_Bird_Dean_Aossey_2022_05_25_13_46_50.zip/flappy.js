var pipes = []
var bird;

function setup() {
  createCanvas(400, 500);
  bird = new Bird();
 pipes.push(new Pipe());
}

function draw() {
  background(500);
  fill(50, 0, 0);
  textSize(20);
   for (var i = pipes.length - 1; i >= 0; i--) {
    pipes[i].show();
    pipes[i].update();
    if (pipes[i].hits(bird)) {
     
    }else if(frameCount%100 == 0){
     
    } 
    if (pipes[i].offscreen()) {
      pipes.splice(i, 1)
    }
  }
  bird.show();
  bird.update();
  if (frameCount % 100 == 0) {
    pipes.push(new Pipe());
  }
 
      }
function keyPressed() {
  if (key == ' ') {
    bird.up();
  }

}